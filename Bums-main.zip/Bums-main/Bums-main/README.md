# Bums

BOT LINK: [Link Bot](https://t.me/bums/app?startapp=ref_Dj10Rbaq)

TELEGRAM GROUP LINK: [Link Channel Telegram](https://t.me/AirdropScript6)

## Features:
| Feature                        | Supported |
|--------------------------------|:---------:|
| Multi-account support          |     ✔     |
| Auto Task (Not All)            |     ✔     |
| Auto Upgrade Mine              |     ✔     |
| Setting in Config              |     ✔     |

Don’t forget to star the project and report any bugs you find. Good luck!
